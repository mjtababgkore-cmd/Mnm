package com.alkhabir.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF102B46)
private val Blue = Color(0xFF245B80)
private val Gold = Color(0xFFD8B66C)
private val Canvas = Color(0xFFF3F6F8)
private val Ink = Color(0xFF172B3A)
private val Muted = Color(0xFF7B8995)
private val Green = Color(0xFF16845B)
private val Red = Color(0xFFB64A4A)

data class DemoTransaction(
    val title: String,
    val subtitle: String,
    val amount: Double,
    val incoming: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlKhabirApp() }
    }
}

@Composable
fun AlKhabirApp() {
    var tab by remember { mutableIntStateOf(0) }
    var balance by remember { mutableDoubleStateOf(10000.0) }
    var showBalance by remember { mutableStateOf(true) }
    var transferOpen by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf<String?>(null) }
    var transactions by remember {
        mutableStateOf(
            listOf(
                DemoTransaction("إيداع تجريبي", "اليوم • 10:25 ص", 5000.0, true),
                DemoTransaction("مشتريات تجريبية", "أمس • 06:40 م", 850.0, false),
                DemoTransaction("تحويل تجريبي", "08 نوفمبر • 01:15 م", 250.0, false),
                DemoTransaction("استرداد تجريبي", "07 نوفمبر • 11:05 ص", 1200.0, true)
            )
        )
    }

    if (transferOpen) {
        TransferDialog(
            balance = balance,
            onDismiss = { transferOpen = false },
            onConfirm = { recipient, amount ->
                balance -= amount
                transactions = listOf(
                    DemoTransaction("تحويل تجريبي إلى $recipient", "الآن • عملية محاكاة", amount, false)
                ) + transactions
                transferOpen = false
                feedback = "تم تسجيل التحويل التجريبي محلياً"
            }
        )
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, background = Canvas, surface = Color.White)) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 10.dp) {
                    val labels = listOf("الرئيسية", "الحسابات", "السجل", "المزيد")
                    val icons = listOf(Icons.Default.Home, Icons.Default.AccountBalanceWallet, Icons.Default.ReceiptLong, Icons.Default.Menu)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
            },
            snackbarHost = {
                SnackbarHost(hostState = remember { SnackbarHostState() })
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(
                    padding, balance, showBalance, transactions.take(3),
                    onToggleBalance = { showBalance = !showBalance },
                    onTransfer = { transferOpen = true },
                    onTab = { tab = it },
                    onFeedback = { feedback = it }
                )
                1 -> AccountsScreen(padding, balance)
                2 -> HistoryScreen(padding, transactions)
                else -> MoreScreen(padding, onFeedback = { feedback = it })
            }
        }
    }

    feedback?.let { message ->
        AlertDialog(
            onDismissRequest = { feedback = null },
            title = { Text("الخبير", fontWeight = FontWeight.Bold) },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { feedback = null }) { Text("حسناً") } }
        )
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues,
    balance: Double,
    showBalance: Boolean,
    latest: List<DemoTransaction>,
    onToggleBalance: () -> Unit,
    onTransfer: () -> Unit,
    onTab: (Int) -> Unit,
    onFeedback: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("مرحباً بعودتك", color = Muted, fontSize = 13.sp)
                    Text("أهلاً بك في الخبير", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(46.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.NotificationsNone, contentDescription = "الإشعارات", tint = Navy)
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Navy, Blue)), RoundedCornerShape(25.dp))
                    .padding(22.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("إجمالي الرصيد التجريبي", color = Color.White.copy(alpha = .8f), fontSize = 13.sp)
                    Icon(Icons.Default.AccountBalance, contentDescription = null, tint = Gold, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (showBalance) money(balance) else "••••••••", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text("وحدة", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onToggleBalance) {
                        Icon(if (showBalance) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = "إظهار الرصيد", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(17.dp))
                HorizontalDivider(color = Color.White.copy(alpha = .2f))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الحساب الرئيسي", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    Text("KH •••• 2048", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text("بيئة محاكاة • لا تمثل أموالاً حقيقية", color = Gold, fontSize = 10.sp)
            }
        }
        item {
            Text("الخدمات السريعة", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("تحويل", Icons.Default.SwapHoriz, Modifier.weight(1f), onTransfer)
                QuickAction("دفع", Icons.Default.QrCodeScanner, Modifier.weight(1f)) { onFeedback("خدمة دفع تجريبية — غير متصلة بأي شبكة دفع") }
                QuickAction("كشف حساب", Icons.Default.Description, Modifier.weight(1f)) { onTab(2) }
                QuickAction("الحسابات", Icons.Default.Wallet, Modifier.weight(1f)) { onTab(1) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("آخر العمليات", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { onTab(2) }) { Text("عرض الكل") }
            }
        }
        items(latest) { TransactionItem(it) }
        item {
            Text(
                "الخبير تطبيق مستقل للمحاكاة والاختبار. جميع الأرصدة والحركات المعروضة تجريبية.",
                color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.background(Color.White, RoundedCornerShape(17.dp)).clickable(onClick = onClick).padding(vertical = 13.dp, horizontal = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(39.dp).background(Color(0xFFEAF0F5), CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Navy, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Ink, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TransactionItem(item: DemoTransaction) {
    Row(
        Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(17.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(if (item.incoming) Color(0xFFE8F4EE) else Color(0xFFF1F3F5), CircleShape), contentAlignment = Alignment.Center) {
            Icon(if (item.incoming) Icons.Default.SouthWest else Icons.Default.NorthEast, contentDescription = null, tint = if (item.incoming) Green else Muted)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(item.subtitle, color = Muted, fontSize = 10.sp)
        }
        Text(
            (if (item.incoming) "+ " else "− ") + money(item.amount),
            color = if (item.incoming) Green else Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp
        )
    }
}

@Composable
private fun AccountsScreen(padding: PaddingValues, balance: Double) {
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("حساباتي", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("إدارة الحسابات التجريبية", color = Muted, fontSize = 12.sp)
        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Navy, Blue)), RoundedCornerShape(22.dp)).padding(20.dp)) {
            Text("الحساب الرئيسي", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
            Spacer(Modifier.height(13.dp))
            Text(money(balance) + " وحدة", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("KH •••• 2048", color = Gold, fontSize = 13.sp)
            Text("حساب محاكاة محلي", color = Color.White.copy(alpha = .7f), fontSize = 10.sp)
        }
        InfoCard("نوع الحساب", "حساب تجريبي")
        InfoCard("حالة الحساب", "نشط – وضع المحاكاة")
        InfoCard("العملة", "وحدة تجريبية")
    }
}

@Composable
private fun HistoryScreen(padding: PaddingValues, transactions: List<DemoTransaction>) {
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("كشف العمليات", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("سجل الحركات التجريبية على هذا الجهاز", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
        }
        items(transactions) { TransactionItem(it) }
        item { Text("نهاية السجل التجريبي", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(14.dp), textAlign = TextAlign.Center) }
    }
}

@Composable
private fun MoreScreen(padding: PaddingValues, onFeedback: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("المزيد", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        InfoCard("الملف الشخصي", "مستخدم تجريبي")
        InfoCard("اللغة", "العربية")
        InfoCard("الأمان", "قفل تجريبي غير مرتبط بخدمة مصرفية")
        InfoCard("حول التطبيق", "الخبير • إصدار 1.1.0")
        OutlinedButton(onClick = { onFeedback("هذا التطبيق مستقل وتجريبي، ولا يمثل بنكاً أو مؤسسة مالية.") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Info, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("حول بيئة المحاكاة")
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Muted)
    }
}

@Composable
private fun TransferDialog(balance: Double, onDismiss: () -> Unit, onConfirm: (String, Double) -> Unit) {
    var recipient by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val amount = amountText.toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تحويل تجريبي", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("سيتم تسجيل الحركة محلياً فقط، ولن يتم إرسال أموال.", color = Muted, fontSize = 12.sp)
                OutlinedTextField(value = recipient, onValueChange = { recipient = it }, label = { Text("اسم المستفيد التجريبي") }, singleLine = true)
                OutlinedTextField(
                    value = amountText, onValueChange = { amountText = it; error = "" },
                    label = { Text("المبلغ") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                if (error.isNotBlank()) Text(error, color = Red, fontSize = 11.sp)
                Text("الرصيد المتاح: ${money(balance)} وحدة", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    recipient.isBlank() -> error = "أدخل اسم مستفيد تجريبي"
                    amount == null || amount <= 0.0 -> error = "أدخل مبلغاً صحيحاً"
                    amount > balance -> error = "المبلغ أكبر من الرصيد التجريبي"
                    else -> onConfirm(recipient.trim(), amount)
                }
            }) { Text("تأكيد تجريبي") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun money(value: Double): String =
    NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }.format(value)
